/*Fila 3, asiento 10
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab9p1_josuerivera;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.util.Random;
/**
 *
 * @author josue
 */
public class Lab9p1_JosueRivera {
static Random rand = new Random();
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        /*pantallaGusano screen = new pantallaGusano();
        screen.setVisible(true);
        screen.setLocationRelativeTo(null);*/
        // TODO code application logic here
        ArrayList<String> Instrucciones = new ArrayList<>();
        int fila = Integer.parseInt(JOptionPane.showInputDialog("ingrese el numero de filas"));
        while(fila < 4 || fila > 10){
            fila = Integer.parseInt(JOptionPane.showInputDialog("error, vuelva a ingresar el numero de filas"));
        }
        int columna = Integer.parseInt(JOptionPane.showInputDialog("ingrese el numero de las columnas"));
        while(columna < 4 || columna > 10){
            columna = Integer.parseInt(JOptionPane.showInputDialog("error, vuelva a ingresar el numero de columnas"));
        }
        Gusanito g = new Gusanito(fila,columna);
        g.llenar_matriz();
        String mat = g.mattoString();
        int opcion = Integer.parseInt(JOptionPane.showInputDialog(mat +"\n"+"1. Ingresar instruccion"+"\n"+"2.Ejecutar instrucciones"));
        while(opcion <1 || opcion > 2){
            opcion = Integer.parseInt(JOptionPane.showInputDialog("Error, vuelva a introducir su opcion"+"\n"+mat +"\n"+"1. Ingresar instruccion"+"\n"+"2.Ejecutar instrucciones"));
        }
        int opcion2=0;
        while(opcion2 == 0){
            switch (opcion){
                case 1:
                    String move = JOptionPane.showInputDialog(mat+"\n"+"ingrese la instruccion en la forma magnitud Direccion(ej.2UP)");
                    Instrucciones.add(move);
                    System.out.println("ok1");
                    break;
                    
                case 2:
                    g.setIntrucciones(Instrucciones);
                    g.Mostrar_Pasos(mat);
                    System.out.println("ok2");
                    
                    break;

            }
            opcion = Integer.parseInt(JOptionPane.showInputDialog(mat +"\n"+"1. Ingresar instruccion"+"\n"+"2.Ejecutar instrucciones"));
            while(opcion <1 || opcion > 2){
                opcion = Integer.parseInt(JOptionPane.showInputDialog("Error, vuelva a introducir su opcion"+"\n"+mat +"\n"+"1. Ingresar instruccion"+"\n"+"2.Ejecutar instrucciones"));
            }
        }
    }
    
}
