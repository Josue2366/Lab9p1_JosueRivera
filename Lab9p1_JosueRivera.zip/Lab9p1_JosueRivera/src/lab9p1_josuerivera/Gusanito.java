/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab9p1_josuerivera;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author josue
 */
public class Gusanito {
    static Random rand = new Random();
    ArrayList<String> intrucciones ;
    char [][] Tablero;
    int gusx;
    int gusy;
    int manx;
    int many;
    int x;
    int y;
    

    public Gusanito(int i,int j) {
        this.x = i;
        this.y = j;
        this.Tablero = new char[i][j];
        this.gusy = rand.nextInt(j);
        this.gusx = rand.nextInt(i);
        this.many = rand.nextInt(j);
        this.manx = rand.nextInt(i);
        
            
        
    }

    public Gusanito() {
    }

    public int getGusx() {
        return gusx;
    }

    public void setGusx(int gusx) {
        this.gusx = gusx;
    }

    public int getGusy() {
        return gusy;
    }

    public void setGusy(int gusy) {
        this.gusy = gusy;
    }

    public ArrayList<String> getIntrucciones() {
        return intrucciones;
    }

    public void setIntrucciones(ArrayList<String> intrucciones) {
        this.intrucciones = intrucciones;
    }
    
    public char [][] llenar_matriz(){
        for (int i = 0; i < Tablero.length; i++) {
            for (int j = 0; j < Tablero[i].length; j++) {
                Tablero[i][j]= ' ';
            }
            
        }
        int obsx;
        int obsy;
        Tablero [gusx][gusy]= 's';
        Tablero [manx][many]= 'o';
        int max;
        int men;
        if(x < y){
            max = y;
            men = x;
        }
        else{
            max = x;
            men = y;
        }
        int obs = rand.nextInt((max-men)+1)+men;
        for (int f = 0; f < obs; f++) {
            obsx = rand.nextInt(x);
            while(obsx == gusy || obsx == gusx  || obsx == manx || obsx == many){
                obsx = rand.nextInt(x);
            }
            obsy = rand.nextInt(y);
            while(obsy == gusy || obsy == gusx  || obsy == manx || obsy == many){
                obsy = rand.nextInt(y);
            }
            Tablero [obsx][obsy]='#';
        }    
        return Tablero;
    }
    public void imprimir(){
        for (int i = 0; i < Tablero.length; i++) {
            for (int j = 0; j < Tablero[i].length; j++) {
                System.out.print("["+ Tablero[i][j]+"]");
            }
            System.out.println("");
            
        }
    }
    public String mattoString(){
        String m = "";
        for (int i = 0; i < Tablero.length; i++) {
            for (int j = 0; j < Tablero[i].length; j++) {
                m += "["+Tablero[i][j]+"]"+" "+"\t";
            }
            m += "\n";
            
        }
        return m;
    }
    public String mattoString2(char [][] x){
        String m = "";
        for (int i = 0; i < x.length; i++) {
            for (int j = 0; j < x[i].length; j++) {
                m += "["+x[i][j]+"]"+" "+"\t";
            }
            m += "\n";
            
        }
        return m;
    }
    public void Mostrar_Pasos(String mat){
        Gusanito p = new Gusanito();
        char [][] temp= Tablero;
        String temp1;
        int cont = 0;
        int pasar = 0;
        String rond2;
        temp1 =p.mattoString2(temp);
            
        
            int intru = Integer.parseInt(JOptionPane.showInputDialog(
                    temp1+"\n"+"1. ver siguente paso"+"\n"+"2. ver paso anterior"+"\n"+"3.Seleccionar paso"+"\n"+"4. Volver al menu"));
            while (intru > 0 || intru < 4){
                switch(intru){
                    case 1:
                      
                        if(cont+1 == intrucciones.size()){
                          intru = Integer.parseInt(JOptionPane.showInputDialog(
                        temp1+"\n"+"ya no hay mas movimientos"+"\n"+"1. ver siguente paso"+"\n"+"2. ver paso anterior"+"\n"+"3.Seleccionar paso"+"\n"+"4. Volver al menu"));
                          break;
                      
                        }
                        else {
                            for (int i = 0; i <= cont; i++) {


                              String rond = intrucciones.get(i);
                              int move = rond.charAt(0) -'0';
                              rond2 = ""+(rond.charAt(1)-'0')+(rond.charAt(2)-'0');
                              if (rond2.equals("UP")){
                                  if ((gusx - move) < 0){
                                      pasar = gusx - move;
                                      intru = Integer.parseInt(JOptionPane.showInputDialog(
                                                temp1+"\n"+"Te pasaste:"+pasar+"1. ver siguente paso"+"\n"+"2. ver paso anterior"+"\n"+"3.Seleccionar paso"+"\n"+"4. Volver al menu"));
                                      break;
                                  }
                                  Tablero [gusx][gusy]= ' ';
                                  p.setGusy(gusx-move);
                                  Tablero [gusx][gusy] = 's';


                              }
                              else if (rond2.equals("DN")){
                                  if ((gusx + move) > x){
                                      pasar = gusx + move;
                                      intru = Integer.parseInt(JOptionPane.showInputDialog(
                                                temp1+"\n"+"Te pasaste:"+pasar+"1. ver siguente paso"+"\n"+"2. ver paso anterior"+"\n"+"3.Seleccionar paso"+"\n"+"4. Volver al menu"));
                                      break;
                                  }
                                  Tablero [gusx][gusy]= ' ';
                                  p.setGusy(gusx+move);
                                  Tablero [gusx][gusy] = 's';
                              }
                              else if( rond2.equals("RT")){
                                  if ((gusy + move) > y){
                                      pasar = gusy + move;
                                      intru = Integer.parseInt(JOptionPane.showInputDialog(
                                                temp1+"\n"+"Te pasaste:"+pasar+"1. ver siguente paso"+"\n"+"2. ver paso anterior"+"\n"+"3.Seleccionar paso"+"\n"+"4. Volver al menu"));
                                      break;
                                  }
                                  Tablero [gusx][gusy]= ' ';
                                  p.setGusx(gusy+move);
                                  Tablero [gusx][gusy] = 's';

                              }
                              else if (rond2.equals("LT")){
                                  if ((gusy - move) < 0){
                                      pasar = gusy - move;
                                      intru = Integer.parseInt(JOptionPane.showInputDialog(
                                                temp1+"\n"+"Te pasaste:"+pasar+"1. ver siguente paso"+"\n"+"2. ver paso anterior"+"\n"+"3.Seleccionar paso"+"\n"+"4. Volver al menu"));
                                      break;
                                  }
                                  Tablero [gusx][gusy]= ' ';
                                  p.setGusx(gusy-move);
                                  Tablero [gusx][gusy] = 's';
                              }
                              
                            }
                            temp = Tablero;
                            temp1 =p.mattoString2(temp);
                            cont++;
                            intru = Integer.parseInt(JOptionPane.showInputDialog(
                            temp1+"\n"+"1. ver siguente paso"+"\n"+"2. ver paso anterior"+"\n"+"3.Seleccionar paso"+"\n"+"4. Volver al menu"));
                        }
                    case 2:
                        if (cont == 0){
                            intru = Integer.parseInt(JOptionPane.showInputDialog(
                            temp1+"\n"+"no hay movimientos previos"+"\n"+"1. ver siguente paso"+"\n"+"2. ver paso anterior"+"\n"+"3.Seleccionar paso"+"\n"+"4. Volver al menu"));
                        }
                        else{
                            int cont_temp = cont - 1;
                            for (int i = 0; i <= cont_temp; i++) {


                              String rond = intrucciones.get(i);
                              int move = rond.charAt(0) -'0';
                              rond2 = ""+(rond.charAt(1)-'0')+(rond.charAt(2)-'0');
                              if (rond2.equals("UP")){
                                  if ((gusx - move) < 0){
                                      pasar = gusx - move;
                                      intru = Integer.parseInt(JOptionPane.showInputDialog(
                                                temp1+"\n"+"Te pasaste:"+pasar+"1. ver siguente paso"+"\n"+"2. ver paso anterior"+"\n"+"3.Seleccionar paso"+"\n"+"4. Volver al menu"));
                                      break;
                                  }
                                  Tablero [gusx][gusy]= ' ';
                                  p.setGusy(gusx-move);
                                  Tablero [gusx][gusy] = 's';


                              }
                              else if (rond2.equals("DN")){
                                  if ((gusx + move) > x){
                                      pasar = gusx + move;
                                      intru = Integer.parseInt(JOptionPane.showInputDialog(
                                                temp1+"\n"+"Te pasaste:"+pasar+"1. ver siguente paso"+"\n"+"2. ver paso anterior"+"\n"+"3.Seleccionar paso"+"\n"+"4. Volver al menu"));
                                      break;
                                  }
                                  Tablero [gusx][gusy]= ' ';
                                  p.setGusy(gusx+move);
                                  Tablero [gusx][gusy] = 's';
                              }
                              else if( rond2.equals("RT")){
                                  if ((gusy + move) > y){
                                      pasar = gusy + move;
                                      intru = Integer.parseInt(JOptionPane.showInputDialog(
                                                temp1+"\n"+"Te pasaste:"+pasar+"1. ver siguente paso"+"\n"+"2. ver paso anterior"+"\n"+"3.Seleccionar paso"+"\n"+"4. Volver al menu"));
                                      break;
                                  }
                                  Tablero [gusx][gusy]= ' ';
                                  p.setGusx(gusy+move);
                                  Tablero [gusx][gusy] = 's';

                              }
                              else if (rond2.equals("LT")){
                                  if ((gusy - move) < 0){
                                      pasar = gusy - move;
                                      intru = Integer.parseInt(JOptionPane.showInputDialog(
                                                temp1+"\n"+"Te pasaste:"+pasar+"1. ver siguente paso"+"\n"+"2. ver paso anterior"+"\n"+"3.Seleccionar paso"+"\n"+"4. Volver al menu"));
                                      break;
                                  }
                                  Tablero [gusx][gusy]= ' ';
                                  p.setGusx(gusy-move);
                                  Tablero [gusx][gusy] = 's';
                              }
                              
                            }
                            temp = Tablero;
                            cont++;
                            intru = Integer.parseInt(JOptionPane.showInputDialog(
                            temp1+"\n"+"1. ver siguente paso"+"\n"+"2. ver paso anterior"+"\n"+"3.Seleccionar paso"+"\n"+"4. Volver al menu"));
                        }
                    case 3:
                        int cont_elegir = Integer.parseInt(JOptionPane.showInputDialog("Ingrese que paso le gustaria ver"));
                        for (int i = 0; i <= cont_elegir; i++) {


                              String rond = intrucciones.get(i);
                              int move = rond.charAt(0) -'0';
                              rond2 = ""+(rond.charAt(1)-'0')+(rond.charAt(2)-'0');
                              if (rond2.equals("UP")){
                                  if ((gusx - move) < 0){
                                      pasar = gusx - move;
                                      intru = Integer.parseInt(JOptionPane.showInputDialog(
                                                temp1+"\n"+"Te pasaste:"+pasar+"1. ver siguente paso"+"\n"+"2. ver paso anterior"+"\n"+"3.Seleccionar paso"+"\n"+"4. Volver al menu"));
                                      break;
                                  }
                                  Tablero [gusx][gusy]= ' ';
                                  p.setGusy(gusx-move);
                                  Tablero [gusx][gusy] = 's';


                              }
                              else if (rond2.equals("DN")){
                                  if ((gusx + move) > x){
                                      pasar = gusx + move;
                                      intru = Integer.parseInt(JOptionPane.showInputDialog(
                                                temp1+"\n"+"Te pasaste:"+pasar+"1. ver siguente paso"+"\n"+"2. ver paso anterior"+"\n"+"3.Seleccionar paso"+"\n"+"4. Volver al menu"));
                                      break;
                                  }
                                  Tablero [gusx][gusy]= ' ';
                                  p.setGusy(gusx+move);
                                  Tablero [gusx][gusy] = 's';
                              }
                              else if( rond2.equals("RT")){
                                  if ((gusy + move) > y){
                                      pasar = gusy + move;
                                      intru = Integer.parseInt(JOptionPane.showInputDialog(
                                                temp1+"\n"+"Te pasaste:"+pasar+"1. ver siguente paso"+"\n"+"2. ver paso anterior"+"\n"+"3.Seleccionar paso"+"\n"+"4. Volver al menu"));
                                      break;
                                  }
                                  Tablero [gusx][gusy]= ' ';
                                  p.setGusx(gusy+move);
                                  Tablero [gusx][gusy] = 's';

                              }
                              else if (rond2.equals("LT")){
                                  if ((gusy - move) < 0){
                                      pasar = gusy - move;
                                      intru = Integer.parseInt(JOptionPane.showInputDialog(
                                                temp1+"\n"+"Te pasaste:"+pasar+"1. ver siguente paso"+"\n"+"2. ver paso anterior"+"\n"+"3.Seleccionar paso"+"\n"+"4. Volver al menu"));
                                      break;
                                  }
                                  Tablero [gusx][gusy]= ' ';
                                  p.setGusx(gusy-move);
                                  Tablero [gusx][gusy] = 's';
                              }
                              
                            }
                            temp = Tablero;
                            cont++;
                            intru = Integer.parseInt(JOptionPane.showInputDialog(
                            temp1+"\n"+"1. ver siguente paso"+"\n"+"2. ver paso anterior"+"\n"+"3.Seleccionar paso"+"\n"+"4. Volver al menu"));
                }
            
        }
        
    }
    
    
}
